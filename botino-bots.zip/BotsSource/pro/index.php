<?php
/*
این سورس بصورت کامل و صفر تا صد توسط @Mr_unk نوشته شده است.
جهت حمایت  از صاحب اثر وارد کانال شوید و این پیام را پاک نکنید
حـــــرام اســـــت
کانال : @TeknoTM
** این سورس نیازی به آموزش ندارد
فقط لاین توکن و قسمت متغیر هارا ادیت کنید :)
**** بهترین سورس ارسال پروکسی در کانال *****
ما هر چند روز سورس مینویسیم و اپن میکنیم
حتما به ما سر بزنید شاید سورس هایی که نوشتیم و اپن کردیم
بدردتون بخوره
@TeknoTM @TeknoTM
کانال پروکسی ما با سورس همین ربات : @TeknoProxy
نمونه این سورس : @TeknoProxyBot
*/
error_reporting(0);
define('API_KEY','[*[TOKEN]*]'); // توکن ربات
ini_set("log_errors","off");
//------- فانکشن
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//------ متغیر
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$textmessage = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$contact = $message->contact;
$contactid = $contact->user_id;
$contactnum = $contact->phone_number;
//- بخش ادیت --------------------####----
$admin = "[*[ADMIN]*]"; // ایدی عددی ادمین
$botToken = "[*[TOKEN]*]"; // توکن ربات
$channeltag = "[*[CHENNEL]*]"; // ایدی کانال بدون @
$bottag = "[*[BOT]*]"; // ایدی ربات بدون @
$proxy2 = '@[*[CHENNEL]*]'; // یوزرنیم کانال ارسال پراکسی با @
$proxy22 = '[*[CHENNEL]*]'; // یوزرنیم کانال ارسال پراکسی بدون @
$prox = '[*[BOT]*]'; // ایدی ربات ارسال پروکسی بدون @
$bots = '[*[BOT]*]'; // ایدی ربات پشتیبانی بدون @
////-----دیگر متغیر ها----------$--$-$$$$$-
$username = $message->from->username;
$rpto = $update->message->reply_to_message->forward_from->id;
$user = json_decode(file_get_contents("data/$from_id.json"),true);
$step = $user["step"];
$createfree = $user["createfree"];
$createbot = $user["createbot"];
$type = $user["type"];
$invite = $user["invite"];
$storebot = $user["storebot"];
$yourbotsaz = $user["yourbotsaz"];
$freebots = file_get_contents("data/freebots.txt");
$vipbots = file_get_contents("data/vipbots.txt");
$forchaneel = json_decode(file_get_contents("https://api.telegram.org/bot$botToken/getChatMember?chat_id=@$channeltag&user_id=".$chat_id));
$tch = $forchaneel->result->status;
$settings = json_decode(file_get_contents("data/settings.json"),true);
$data = $update->callback_query->data;
$messageid = $update->callback_query->message->message_id;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->inline_query->from->id;
$settings = json_decode(file_get_contents("data/settings.json"),true);
//----
$proxy = $settings["chlog"];
$c_id1 = $message->forward_from_chat->username;
$c_id2 = $message->forward_from_chat->id;
//-----دیگر فانکشن-
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}
function deletefolder($path) { 
if ($handle=opendir($path)) { 
while (false!==($file=readdir($handle))) { 
if ($file<>"." AND $file<>"..") { 
if (is_file($path.'/'.$file))  { 
@unlink($path.'/'.$file); 
} 
if (is_dir($path.'/'.$file)) { 
deletefolder($path.'/'.$file); 
@rmdir($path.'/'.$file); 
} 
} 
} 
} 
}
function SendVideo($chatid,$video,$caption,$keyboard,$duration){
bot('SendVideo',[
'chat_id'=>$chatid,
'video'=>$video,
'caption'=>$caption,
'duration'=>$duration,
'reply_markup'=>$keyboard
]);
}
function EditMessageText($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
	 bot('editMessagetext',[
    'chat_id'=>$chat_id,
	'message_id'=>$message_id,
    'text'=>$text,
    'parse_mode'=>$parse_mode,
	'disable_web_page_preview'=>$disable_web_page_preview,
    'reply_markup'=>$keyboard
	]);
	}
	date_default_timezone_set('Asia/Tehran');
function ToFa($n){
$fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
$en = range(0,9);
return str_replace($en,$fa,$n);
}
$time = ToFa(date('H:i:s'));
$date = ToFa(date('Y/m/d'));
//------
//------شروع ربات-------//
if(strpos($textmessage,"/start") !== false  && $textmessage !=="/start"){
$id=str_replace("/start ","",$textmessage);
$amar=file_get_contents("data/members.txt");
$exp=explode("\n",$amar);
if(!in_array($from_id,$exp) && $from_id != $id){
$myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
$user["step"] = "none";
$user["invite"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
$user1 = json_decode(file_get_contents("data/$id.json"),true);
$invite = $user1["invite"];
settype($invite,"integer");
$newinvite = $invite + 1;
$user1["invite"] = $newinvite;
$outjson = json_encode($user1,true);
file_put_contents("data/$id.json",$outjson);
bot('sendMessage',[
'chat_id'=>$id,
'text'=>"✅یک نفر از طریق لینک اختصاصی شما به ربات پیوست..",
'parse_mode'=>"HTML",
]);						
}
}
if (!file_exists("data/$from_id.json")) {
        $myfile2 = fopen("data/members.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
		 $user["step"] = "none";
		 $user["invite"] = "0";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    }
	if($tch != 'member' && $tch != 'creator' && $tch != 'administrator'){
		 bot('sendMessage',[
'chat_id'=>$chat_id,
  'text'=>"🔹 سلام کاربر گرامی به ربات ارسال پراکسی در کانال خوش آمدید.
  جهت کارکرد ربات شما باید در کانال زیر عضو شوید👇
--------------
  🌟 @$channeltag      🌟 @$channeltag
                   🌟 @$channeltag
-----------
بعد از عضویت /start را دوباره بزنید.
",
'parse_mode'=>"HTML",
]);
}else{ 
	if($textmessage == "/start" or $textmessage == "شروع"){
	$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🍻سلام به ربات ارسال پراکسی خوش آمدید ! ورود شمارا تبریک میگوییم !
➖➖➖➖➖
🛡نام شما   $first_name
🛡آیدی عددی شما <code>$chat_id</code> 
➖➖➖➖➖
📌 این ربات فقط برای آدمین کاربرد دارد و برای اعضای معمولی کاربرد خاصی ندارد ...

😃 با داشتن این سورس می توانید به کانال پروکسی تان ، پروکسی ارسال کنید به دو صورت فوری و زمان دارد
که این قابلیت در پنل مدیریت در دسترس است ! و فقط دارنده سورس می تواند به کانال خود پراکسی ارسال کند.
😄 اما شما اگر پراکسی فعالی دارید می توانید به ما ارسال کنید تا به کانال ما کمک کنید ... جهت ارسال پراکسی به ما و قرار دادن آن در کانال لطفا گزینه ( ارسال پراکسی به ما ) را بزنید !

🎗پروکسی شما بعد از #تایید به کانال ما ارسال خواهد شد .

👇 از دکمه های زیر استفاده کنید.
 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🔱ارسال پروکسی"],['text'=>"🔆آخرین پروکسی"]],
[['text'=>"رباتساز رایگان 🌟"]],
	],
"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	}
		 	 //---
	  if($textmessage == "زمان"){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"$time و $date
 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
	 }
	 	  elseif($textmessage == "رباتساز رایگان 🌟"){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"✅ با اپلیکیشن باتینو بینهایت ربات بساز !
✅ 40 نوع ربات !
✅ کاملا رایگان !

📥 دانلود ->     @botinoApk",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]);  
	 }
	 elseif($textmessage == "🔙" or $textmessage == "برگشت"){
	 $user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
 ✅ به منوی اصلی برگشتید.
 ➖➖➖➖➖
👇 از دکمه های زیر استفاده کنید.
 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
[['text'=>"🔱ارسال پروکسی"],['text'=>"🔆آخرین پروکسی"]],
[['text'=>"رباتساز رایگان 🌟"]],
	],
"resize_keyboard"=>true,
	 ])
	 ]); 
	}
	 elseif($textmessage == "🔆آخرین پروکسی"){
	  bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"😄 جهت دریافت آخرین پراکسی ها کلیک کنید",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
            'inline_keyboard'=>[
[['text'=>"◾️ ورود به کانال ◾️", 'url'=>"https://t.me/$proxy22"]],
              ]
        ])
   ]); 
   }
   elseif($textmessage == "🔱ارسال پروکسی"){
		  $user["step"] = "support";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
		  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🌹 بخاطر همکاری شما صمیمانه سپاسگزاریم ! لطفا اگر پروکسی فعالی دارید می توانید به ما ارسال کنید تا در کانال قرار دهیم !
🔹 پروکسی باید حتما فعال باشد
🔹 حتما پروکسی را بصورت لینک ارسال کنید 
➖➖➖
نمونه ارسال پروکسی : https://t.me/proxy?server=Jurd.Verginia.dynu.com&port=9090&secret=00000000000000000000000000000000
➖➖➖➖
🛡حال پروکسی خود را ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]);  
	  }
elseif($step == "support" and $textmessage != "🔙"){
      bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"✅ پروکسی شما با موفقیت ارسال شد پس از تایید پروکسی شما در کانال $proxy2 نمایش داده خواهد شد.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"🔙"]],
 ],
  "resize_keyboard"=>true,
  ])
  ]);  
bot('sendMessage',[
 'chat_id'=>$chat_id,
'text'=>"😄 کاربر گرامی ، دوست عزیز و همراه ما در صورتی که دوست دارید به پشتیبانی جهت سوال کردن و... مراجعه کنید لطفا روی لینک زیر بزنید و وارد بات پشتیبانی شوید.",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
            'inline_keyboard'=>[
[['text'=>"👥 ربات پشتیبانی و ارسال نظر", 'url'=>"https://t.me/$bots"]],
              ]
        ])
   ]); 
     bot('ForwardMessage',[
 'chat_id'=>$admin,
 'from_chat_id'=>$from_id,
 'message_id'=>$message_id
 ]);
    }
    elseif($rpto != "" && $chat_id == $admin){
     bot('sendMessage',[
 'chat_id'=>$rpto,
 'text'=>"🔹 $textmessage",
 'parse_mode'=>"HTML",
  ]);
       bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"🌹مدیر گرامی پیغام شما با موفقیت برای فرد ارسال شد✅",
 'parse_mode'=>"HTML",
  ]);
    }
	 //-----admin-panel-----
elseif($textmessage == "مدیریت" or $textmessage == "پنل" or $textmessage == "/panel"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	if($chat_id == $admin ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>" به پنل مدیریت خوش آمدید🎈
✅ <code> شما آدمین شناخته شدید </code>
➖➖➖➖➖➖➖➖
💭اسم شما : $first_name
⏳ آیدی عددی شما آدمین گرامی : $chat_id می باشد !
➖➖➖➖➖➖➖➖
🎗 آدمین گرامی شما در اینجا می توانید به کانال پروکسی خود با آیدی $proxy2 پیام بفرستید !
اگر هنوز تنظیم نکرده اید باید در سورس ربات تنظیم کنید . . . .  !
📌 درصورتی که نیاز به راهنمایی دارید روی گزینه راهنمای پنل بزنید .
قبل از هرچیزی باید کانال ارسال پروکسی خود را تنظیم کنید
👇 یکی از گزینه هارا انتخاب کنید 👇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"👥آمار کلی ربات👥"]],
    	[['text'=>"📮پیام همگانی📮"],['text'=>"📤فوروارد همگانی📤"]],
    	[['text'=>"✅تنظیم کانال ارسال پروکسی✅"]],
    	[['text'=>"⏰ارسال زماندار"],['text'=>"🛰 ارسال فـــوری"]],
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"😑شما دسترسی به بخش مدیریت را ندارید!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
///*-*-*-*-*-**-*-*-*-*--*-*-*-*-*---
elseif($textmessage == "🔹بازگشت به پنل"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	if($chat_id == $admin ){
	bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"📍 به منوی اصلی پنل مدیریت #برگشتید!
🔹 <code> درصورتی که نیاز به راهنمایی دارید روی گزینه راهنمای پنل بزنید</code>
قبل از هرچیزی باید کانال ارسال پروکسی خود را تنظیم کنید
➖➖➖➖➖➖➖➖
👇 یکی از گزینه های زیر را انتخاب کنید 👇",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
    [['text'=>"👥آمار کلی ربات👥"]],
    	[['text'=>"📮پیام همگانی📮"],['text'=>"📤فوروارد همگانی📤"]],
    	[['text'=>"✅تنظیم کانال ارسال پروکسی✅"]],
    	[['text'=>"⏰ارسال زماندار"],['text'=>"🛰 ارسال فـــوری"]],
	[['text'=>"🔙"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}else{
		bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"😑شما دسترسی به بخش مدیریت را ندارید!",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
	 ]); 
}
}
//---
elseif($chat_id == $admin and $textmessage == "📮پیام همگانی📮"){	
$user["step"] = "send2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای ارسال همگانی ارسال نمایید➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($chat_id == $admin && $step == "send2all" && $textmessage != "🔹بازگشت به پنل"){ 
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
	while( !feof( $all_member)) {
 	$user = fgets( $all_member);
  bot('sendMessage',[
 'chat_id'=>$user,
 'text'=>$textmessage,
 'parse_mode'=>"HTML",
  ]);
}
  bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام همگانی با موفقیت به همه اعضا ارسال شد✔️",
 'parse_mode'=>"HTML",
  ]);
}
//----
elseif($chat_id == $admin and $textmessage == "📤فوروارد همگانی📤"){
	$user["step"] = "f2all";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"پیام خود را برای فروارد همگانی فروارد نمایید➰",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
]); 
}
elseif($textmessage != "🔹بازگشت به پنل" && $from_id == $admin && $step == "f2all"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
    $all_member = fopen( "data/members.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
		   bot('ForwardMessage',[
	'chat_id'=>$user,
	'from_chat_id'=>$admin,
	'message_id'=>$message_id
	]);
		}    
		bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"فروارد همگانی به همه اعضای ربات فروارد شد✔️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
	 	 	 //-----------------------*-*-*-*
elseif($chat_id == $admin and $textmessage == "👥آمار کلی ربات👥"){	
$alluser = file_get_contents("data/members.txt");
	$alaki = explode("\n",$alluser);
    $allusers = count($alaki)-1;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"➰تعداد کل اعضای ربات : $allusers",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}
 	 	 //------------*--*-*-*-*-*-*-*-*-*-*-*-*
	 elseif($textmessage == "⏰ارسال زماندار"){
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"🙂 مدیر عزیز لطفا انتخاب کنید پراکسی را چند دقیقه یا ثانیه یا ساعت بعد بفرستم تو کاناتون ؟
 <code> جهت ارسال فوری برگردید و به قسمت ارسال فوری بروید🙂</code>
  [ 🔹 S = ثانیه 🔹 M = دقیقه H = ساعت ]
  زمان را انتخاب کنید👇
 ",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
           [['text'=>"5s"],['text'=>"10s"],['text'=>"15s"]],
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
	 	 	 	 	 //-----------------------*-*-*-*
elseif($textmessage == "15s"){
	$user["step"] = "proxy15s";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"🙂 اگر پیامی دریافت نکرده اید یعنی در کانال $proxy2 ارسال شده است!
 
 حال لطفا لینک پراکسی را ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
	 elseif($step == "proxy15s" && $textmessage != "🔹بازگشت به پنل"){ 
	 sleep(15);
	 bot('sendMessage',[
 'chat_id'=>$proxy,
 'text'=>"🌟 پروکسی جدید و پرسرعت🌟
 -----------------
$textmessage
-----------------
⏰ زمان : $time 🗓تاریخ : $date ;)
<code> 🔹 کانـــــال ما : </code> $proxy2 
✅ می توانید از طریق لینک زیر هم به پراکسی وصل شوید
",
 'parse_mode'=>"HTML",
     'reply_markup'=>json_encode([
            'inline_keyboard'=>[
[['text'=>"🚀 اتصال به پراکسی🚀", 'url'=>"$textmessage"]],
              ]
        ])
	 ]); 
	 bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"
 ✅ پروکسی شما با موفقیت به چنل $proxy2 ارسال شد
",
 'parse_mode'=>"HTML",
 	 ]); 
	 }
	 	 	 	 	 //-----------------------*-*-*-*
elseif($textmessage == "10s"){
	$user["step"] = "proxy10s";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"🙂 اگر پیامی دریافت نکرده اید یعنی در کانال $proxy2 ارسال شده است!
 
 حال لطفا لینک پراکسی را ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
	 elseif($step == "proxy10s" && $textmessage != "🔹بازگشت به پنل"){ 
	 sleep(10);
	 bot('sendMessage',[
 'chat_id'=>$proxy,
 'text'=>"🌟 پروکسی جدید و پرسرعت🌟
 -----------------
$textmessage
-----------------
⏰ زمان : $time 🗓تاریخ : $date ;)
<code> 🔹 کانـــــال ما : </code> $proxy2 
✅ می توانید از طریق لینک زیر هم به پراکسی وصل شوید
",
 'parse_mode'=>"HTML",
     'reply_markup'=>json_encode([
            'inline_keyboard'=>[
[['text'=>"🚀 اتصال به پراکسی🚀", 'url'=>"$textmessage"]],
              ]
        ])
	 ]); 
	 bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"
 ✅ پروکسی شما با موفقیت به چنل $proxy2 ارسال شد
",
 'parse_mode'=>"HTML",
 	 ]); 
	 }
	 	 	 	 //-----------------------*-*-*-*
elseif($textmessage == "5s"){
	$user["step"] = "proxy5s";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"🙂 اگر پیامی دریافت نکرده اید یعنی در کانال $proxy2 ارسال شده است!
 
 حال لطفا لینک پراکسی را ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
	 elseif($step == "proxy5s" && $textmessage != "🔹بازگشت به پنل"){ 
	 sleep(5);
	 bot('sendMessage',[
 'chat_id'=>$proxy,
 'text'=>"🌟 پروکسی جدید و پرسرعت🌟
 -----------------
$textmessage
-----------------
⏰ زمان : $time 🗓تاریخ : $date ;)
<code> 🔹 کانـــــال ما : </code> $proxy2 
✅ می توانید از طریق لینک زیر هم به پراکسی وصل شوید
",
 'parse_mode'=>"HTML",
     'reply_markup'=>json_encode([
            'inline_keyboard'=>[
[['text'=>"🚀 اتصال به پراکسی🚀", 'url'=>"$textmessage"]],
              ]
        ])
	 ]); 
	 bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"
 ✅ پروکسی شما با موفقیت به چنل $proxy2 ارسال شد
",
 'parse_mode'=>"HTML",
 	 ]); 
	 }
	 	 	 //-----------------------*-*-*-*
if($textmessage == "🛰 ارسال فـــوری"){
	$user["step"] = "proxy";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
	bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"🙂 اگر پیامی دریافت نکرده اید یعنی در کانال $proxy2 ارسال شده است!
 
 حال لطفا لینک پراکسی را ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔹بازگشت به پنل"]],
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
	 }
	 elseif($step == "proxy" && $textmessage != "🔹بازگشت به پنل"){ 
	 bot('sendMessage',[
 'chat_id'=>$proxy,
 'text'=>"🌟 پروکسی جدید و پرسرعت🌟
 -----------------
$textmessage
-----------------
⏰ زمان : $time 🗓تاریخ : $date ;)
<code> 🔹 کانـــــال ما : </code> $proxy2 
✅ می توانید از طریق لینک زیر هم به پراکسی وصل شوید
",
 'parse_mode'=>"HTML",
     'reply_markup'=>json_encode([
            'inline_keyboard'=>[
[['text'=>"🚀 اتصال به پراکسی🚀", 'url'=>"$textmessage"]],
              ]
        ])
	 ]); 
	 bot('sendMessage',[
 'chat_id'=>$admin,
 'text'=>"
 ✅ پروکسی شما با موفقیت به چنل $proxy2 ارسال شد
",
 'parse_mode'=>"HTML",
 	 ]); 
	 }
elseif($textmessage == "✅تنظیم کانال ارسال پروکسی✅"){
	$user["step"] = "set-channel-log";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id.json",$outjson);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"در این بخش میتوانید کانالی تنظیم کنید که هر گاه لینک پروکسی را به ربات دادید به آن کانال بفرستید.
برای تنظیم کانال ابتدا ربات را ادمین کانال کنید و یک پیام از کانال فروارد کنید😁
توجه داشته باشید که کانال باید عمومی (درای آیدی) باشد❗️",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
if(isset($message->forward_from_chat) && $c_id1 != null ){
if($step == "set-channel-log" and $chat_id == $admin and $textmessage != "🔙"){
$user["step"] = "none";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id.json",$outjson);
$settings["chlog"] = $c_id2;
$outjson1 = json_encode($settings,true);
file_put_contents("data/settings.json",$outjson1);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کانال ارسال پروکسی با موفقیت تنظیم شد✅
آیدی کانال :
@$c_id1
🔹 از این پس هر پروکسی که بفرستید به این کانال ارسال می شود.
",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
           'keyboard'=>[
	[['text'=>"🔙"]],
	
	],
		"resize_keyboard"=>true,
	 ])
	 ]); 
}
}


//--- @TeknoTM #dev = @Mr_unk
/*
این سورس بصورت کامل و صفر تا صد توسط @Mr_unk نوشته شده است.
جهت حمایت  از صاحب اثر وارد کانال شوید و این پیام را پاک نکنید
حـــــرام اســـــت
کانال : @TeknoTM
*/

unlink('error_log');
?>