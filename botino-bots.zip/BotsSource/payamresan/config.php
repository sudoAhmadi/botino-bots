<?php

$Dev = [*[ADMIN]*];
$Token = "[*[TOKEN]*]";
?>